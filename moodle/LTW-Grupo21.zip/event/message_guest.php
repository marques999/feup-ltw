<div class="ink-grid push-center all-50 large-70 medium-80 small-100 tiny-100">
<div class="column ink-alert block error">
<h4>Forbidden</h4>
<p>You don't have permission to access this page!</p>
<p>Please <a href="login.php">log in</a> with your account first.</p>
</div>
</div>