<nav class="ink-navigation half-vertical-space">
<ul class="pagination no-padding">
<li><button><img class="emoticon" alt=":S" src="img/awww.png"></button></li>
<li><button><img class="emoticon" alt=":@" src="img/angry.png"></button></li>
<li><button><img class="emoticon" alt=":|" src="img/disheartened.png"></button></li>
<li><button><img class="emoticon" alt="XD" src="img/ecstatic.png"></button></li>
<li><button><img class="emoticon" alt=":D" src="img/great.png"></button></li>
<li><button><img class="emoticon" alt=":x" src="img/mouthshut.png"></button></li>
<li><button><img class="emoticon" alt=":)" src="img/nice.png"></button></li>
<li><button><img class="emoticon" alt=":o" src="img/omg.png"></button></li>
<li><button><img class="emoticon" alt=":(" src="img/sad.png"></button></li>
<li><button><img class="emoticon" alt=":P" src="img/tongue.png"></button></li>
</ul>
</nav>